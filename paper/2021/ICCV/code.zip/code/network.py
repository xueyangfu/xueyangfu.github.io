#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import tensorflow as tf

def Classifier(images, channels = 32):   
    with tf.variable_scope("Classifier", reuse=tf.AUTO_REUSE):                        
         conv = tf.layers.conv2d(images, channels, 3, padding="VALID", name = 'conv11',activation = tf.nn.relu)        
         conv = tf.layers.conv2d(conv, channels, 3, padding="VALID", name = 'conv12',activation = tf.nn.relu)     
      
         conv = tf.layers.conv2d(conv, channels, 3, strides=2, padding="VALID", name = 'conv21',activation = tf.nn.relu)        
         conv = tf.layers.conv2d(conv, channels, 3, padding="VALID", name = 'conv22',activation = tf.nn.relu) 
      
         conv = tf.layers.conv2d(conv, channels, 3, strides=2, padding="VALID", name = 'conv31',activation = tf.nn.relu)        
         conv = tf.layers.conv2d(conv, channels, 3, padding="VALID", name = 'conv32',activation = tf.nn.relu)
         
         conv = tf.layers.conv2d(conv, channels, 3, strides=2, padding="VALID", name = 'conv41',activation = tf.nn.relu)        
         conv = tf.layers.conv2d(conv, channels, 3, padding="VALID", name = 'conv42',activation = tf.nn.relu) 

         feature = tf.reduce_mean(conv, [1,2], keepdims = True)
         feature = tf.reshape(feature,[-1, channels])       
         fc1 = tf.layers.dense(feature, channels,activation = tf.nn.relu, name = 'fc1')        
         out1 = tf.layers.dense(fc1, 1, name = 'fc2')       
         return tf.nn.sigmoid(out1)


def NonLocal(input_tensor):  
    _, _, _, in_channels = input_tensor.get_shape().as_list()       
    channels = in_channels//2
    
    theta = tf.layers.conv2d(input_tensor, channels, 1, padding="valid")
    theta = tf.reshape(theta, shape=[-1, tf.shape(input_tensor)[1] * tf.shape(input_tensor)[2], channels])

    phi =  tf.layers.conv2d(input_tensor, channels, 1, padding="valid")
    phi =  tf.reshape(phi, shape=[-1, tf.shape(input_tensor)[1] * tf.shape(input_tensor)[2], channels])

    g =  tf.layers.conv2d(input_tensor, channels, 1, padding="valid")
    g =  tf.reshape(g, shape=[-1, tf.shape(input_tensor)[1] * tf.shape(input_tensor)[2], channels])
  
    phi1 = tf.reshape(phi, shape=[-1,  tf.shape(phi)[1] *  tf.shape(phi)[2]])    
    phi1 = tf.nn.softmax(phi1, axis=-1)
    phi1 = tf.reshape(phi1, shape=[-1, tf.shape(phi)[1],  tf.shape(phi)[2]])   

    g1 = tf.reshape(g, shape=[-1,  tf.shape(g)[1] *  tf.shape(g)[2]])    
    g1 = tf.nn.softmax(g1, axis=-1)
    g1 = tf.reshape(g1, shape=[-1, tf.shape(g)[1],  tf.shape(g)[2]])     

    y = tf.matmul(phi1, g1, transpose_a = True)                
    y = tf.matmul(theta, y)
    F_s = tf.reshape(y, shape=[-1,  tf.shape(input_tensor)[1],  tf.shape(input_tensor)[2], channels])
    spatial_out = tf.layers.conv2d(F_s, in_channels, 1, padding="valid")       
    return spatial_out


def Basicblock(_input): 
    _, _, _, channels = _input.get_shape().as_list()  
    
    input_tensor = _input +  NonLocal(_input) 
 
    conv1 = tf.layers.conv2d(input_tensor, channels, 3, dilation_rate=(1, 1), padding="SAME",activation = tf.nn.relu)   
    
    tmp = tf.concat([input_tensor, conv1],-1)     
    conv2 = tf.layers.conv2d(tmp, channels, 3, dilation_rate=(3, 3), padding="SAME",activation = tf.nn.relu)   

    tmp = tf.concat([input_tensor, conv1, conv2],-1)     
    conv3 = tf.layers.conv2d(tmp, channels, 3, dilation_rate=(5, 5), padding="SAME",activation = tf.nn.relu)   

    tmp = tf.concat([input_tensor, conv1, conv2, conv3],-1)       
    fuse = tf.layers.conv2d(tmp, channels, 1, padding="SAME")    
    return   fuse + _input


def Deblocker(images, channels = 112):    
    inchannels = images.get_shape().as_list()[-1]    
    with tf.variable_scope('Deblocker', reuse=tf.AUTO_REUSE):       
         
         with tf.variable_scope('basic'):                     
              basic_fea0 = tf.layers.conv2d(images, channels, 3, padding="SAME")       
              basic_fea1 = tf.layers.conv2d(basic_fea0, channels, 3, padding="SAME")             
                 
         with tf.variable_scope('encoder0'):         
              encode0 =  Basicblock(basic_fea1)                   
         with tf.variable_scope('encoder1'):              
              encode1 =  Basicblock(encode0)         
         with tf.variable_scope('encoder2'): 
              encode2 =  Basicblock(encode1)          
         with tf.variable_scope('encoder3'): 
              encode3 =  Basicblock(encode2)        
         with tf.variable_scope('encoder4'): 
              encode4 =  Basicblock(encode3)      

         with tf.variable_scope('middle'):         
              media_end =   Basicblock(encode4)

         with tf.variable_scope('decoder4'):              
              Deblock4 = tf.concat([media_end, encode4] ,-1)
              Deblock4 = tf.layers.conv2d(Deblock4, channels, 1, padding="SAME")  
              Deblock4 = Basicblock(Deblock4)                    
         with tf.variable_scope('decoder3'):              
              Deblock3 = tf.concat([Deblock4, encode3] ,-1)
              Deblock3 = tf.layers.conv2d(Deblock3, channels, 1, padding="SAME")  
              Deblock3 = Basicblock(Deblock3)                                 
         with tf.variable_scope('decoder2'):              
              Deblock2 = tf.concat([Deblock3, encode2] ,-1)
              Deblock2 = tf.layers.conv2d(Deblock2, channels, 1, padding="SAME")  
              Deblock2 = Basicblock(Deblock2)                  
         with tf.variable_scope('decoder1'):              
              Deblock1 = tf.concat([Deblock2, encode1] ,-1)         
              Deblock1 = tf.layers.conv2d(Deblock1, channels, 1, padding="SAME")  
              Deblock1 =  Basicblock(Deblock1)                  
         with tf.variable_scope('decoder0'):              
              Deblock0 = tf.concat([Deblock1, encode0] ,-1) 
              Deblock0 = tf.layers.conv2d(Deblock0, channels, 1, padding="SAME")
              Deblock0 =  Basicblock(Deblock0) 

         with tf.variable_scope('reconstruct'):      
              decoding_end = tf.concat([Deblock0, basic_fea1] ,-1) 
              decoding_end = tf.layers.conv2d(decoding_end, channels, 3, padding="SAME",activation = tf.nn.relu)                
              decoding_end = decoding_end + basic_fea0
              res =  tf.layers.conv2d(decoding_end, inchannels, 3, padding = 'SAME') 
              out  = images + res    

    return  out