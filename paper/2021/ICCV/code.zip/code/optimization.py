#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import numpy as np
import tensorflow as tf

import network


def psf2otf(input_filter, output_size):
    """Convert 4D tensorflow filter into its FFT."""
    fh, fw, _, _ = input_filter.shape.as_list()
    padded = tf.pad(input_filter, [[0, output_size[0]-fh],
                                  [0, output_size[1]-fw], [0,0], [0,0]], "CONSTANT")

    left = padded[:, 0:(fw-1)//2,:,:]
    right = padded[:, (fw-1)//2:,:,:]
    padded = tf.concat([right, left], 1)

    up = padded[0:(fh-1)//2, :,:,:]
    down = padded[(fh-1)//2:, :,:,:]
    padded = tf.concat([down, up], 0)

    tmp = tf.transpose(padded, [2,3,0,1])
    tmp = tf.fft2d(tf.complex(tmp, 0.))
    return tf.transpose(tmp, [2,3,0,1])


def TV(S):	   
    h_1 = S[:,:,1:,:] - S[:,:,:-1,:]
    h_2 = tf.expand_dims(S[:,:,0,:] - S[:,:,-1,:],2)
    h = tf.concat([h_1,h_2],2)
    
    v_1 = S[:,1:,:,:] - S[:,:-1,:,:]
    v_2 = tf.expand_dims(S[:,0,:,:] - S[:,-1,:,:],1)
    v = tf.concat([v_1,v_2],1)
    return h,v


def TVdiff(h,v):	   
    h_1 = h[:,:,:-1,:]- h[:,:,1:,:] 
    h_2 = tf.expand_dims(h[:,:,-1,:] - h[:,:,0,:],2)
    h = tf.concat([h_2,h_1],2)

    v_1 = v[:,:-1,:,:] - v[:,1:,:,:]
    v_2 = tf.expand_dims(v[:,-1,:,:] - v[:,0,:,:],1)
    v = tf.concat([v_2,v_1],1)
    return h, v
	

def Unfolding(inputs):
    x = inputs
    image_size = tf.shape(inputs)[1:3]   
            
    fx = np.float32([1., -1.]).reshape(1,-1) 
    fx = fx[:,:,None,None]
    fx = tf.constant(fx, dtype='float32')
    otfFx = psf2otf(fx,image_size)      
    otfFx = tf.transpose(otfFx, [2,3,0,1])  

    fy = np.float32([1., -1.]).reshape(-1,1) 
    fy = fy[:,:,None,None]
    fy = tf.constant(fy, dtype='float32')
    otfFy = psf2otf(fy,image_size)
    otfFy = tf.transpose(otfFy,  [2,3,0,1]) 

    x_tensor_transp = tf.transpose(inputs, [0,3,1,2])
    x_tensor_transp = tf.fft2d(tf.complex(x_tensor_transp, 0.))
    Denormin2 = tf.square(tf.abs(otfFx)) + tf.square(tf.abs(otfFy))   
   
    for i in range(5):
        with tf.variable_scope('HyperParam', reuse=tf.AUTO_REUSE):   
             alpha = tf.get_variable('alpha_%d'% (i + 1), initializer=tf.constant(0.01), trainable= True)  
             beta = tf.get_variable('beta_%d'% (i + 1), initializer=tf.constant(0.01), trainable= True)  
             Lambda = tf.get_variable('Lambda_%d'% (i + 1), initializer=tf.constant(0.01), trainable= True)  
             step = tf.get_variable('step_%d'% (i + 1), initializer=tf.constant(0.01), trainable= True) 
      
        U = network.Deblocker(x)
      
        dx,dy = TV(x)
        tmp_x = dx
        tmp_y = dy
      
        for _ in range(3):             
            input_x = tf.concat([dx,dy],-1)
          
            out = network.Classifier(input_x)   
        
            G = tf.gradients(out,input_x)[0]
            grad_x = G[:,:,:,0:1]
            grad_y = G[:,:,:,1:2]
        
            dx = dx - step * (beta * (dx - tmp_x) + Lambda * grad_x)
            dy = dy - step * (beta * (dy - tmp_y) + Lambda * grad_y) 
                   
        h1, v1 = TVdiff(dx,dy)          
        b_tensor_transp = tf.transpose(beta * (h1 + v1), [0,3,1,2])
        b_tensor_transp = tf.fft2d(tf.complex(b_tensor_transp, 0.))
           
        Denormin = tf.complex( (1. + alpha + beta * Denormin2), 0.)
      
        U_tensor_transp = tf.transpose(alpha * U, [0,3,1,2])
        U_tensor_transp = tf.fft2d(tf.complex(U_tensor_transp, 0.))
            
        FS = (x_tensor_transp + U_tensor_transp + b_tensor_transp) / Denormin
        x = tf.real(tf.ifft2d(FS))    
        x = tf.transpose(x, [0,2,3,1])
 
    return x 
    

if __name__ == '__main__':
    tf.reset_default_graph()
    input_x = tf.placeholder(tf.float32, [10,256,256,1])
    out = Unfolding(input_x)   
    all_vars = tf.trainable_variables()
    print("Total parameters' number: %d" %(np.sum([np.prod(v.get_shape().as_list()) for v in all_vars])))  