#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# This is a TensorFlow (version 1.13.1) implementation of testing code of this paper:
# X. Fu, X. Wang, A. Liu, J. Han, Z.-J. Zha. “Learning Dual Priors for JPEG Compression Artifacts Removal”, ICCV, 2021.
# author: Xueyang Fu (xyfu@ustc.edu.cn)


import os
import skimage.io
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

import optimization

tf.reset_default_graph()

input_path = './TestImg/QF10/' # the path of testing images
results_path ='./TestImg/Results/'  # the path of de-blocked images


def _parse_function(filename):      
    image_string = tf.read_file(filename)  
    image_decoded = tf.image.decode_jpeg(image_string, channels = 1)  
    image_decoded = tf.cast(image_decoded, tf.float32)/255.0
    return image_decoded 


if __name__ == '__main__':
   imgName = os.listdir(input_path)
   filename = os.listdir(input_path)
   for i in range(len(filename)):
      filename[i] = input_path + filename[i]
          
   filename_tensor = tf.convert_to_tensor(filename, dtype=tf.string)           
   dataset = tf.data.Dataset.from_tensor_slices((filename_tensor))
   dataset = dataset.map(_parse_function)    
   dataset = dataset.prefetch(buffer_size = 10)
   dataset = dataset.batch(1).repeat()  
   iterator = dataset.make_one_shot_iterator()
  
   JPEG = iterator.get_next()     
   final = optimization.Unfolding(JPEG)   
   final = tf.clip_by_value(final[-1], 0., 1.)[:,:,0]  
  
   config = tf.ConfigProto()
   config.gpu_options.allow_growth=True

   num_imgs = len(filename)
   
   with tf.Session(config=config) as sess:       
        print ("Loading model")        
        var_Classifier = [var for var in tf.trainable_variables()  if 'Classifier' in var.name]     
        saver_Classifier = tf.train.Saver(var_list = var_Classifier)
        saver_Classifier.restore(sess,'./TrainedModel/Classifier/model')
          
        var_Deblocker = [var for var in tf.trainable_variables()  if 'Deblocker' in var.name]    
        var_Deblocker += [var for var in tf.trainable_variables() if 'HyperParam' in var.name]
        saver_Deblocker = tf.train.Saver(var_list = var_Deblocker)
        saver_Deblocker.restore(sess,'./TrainedModel/Deblocker/model')

        for i in range(num_imgs):     
            deblocked, ori = sess.run([final,JPEG])              
            deblocked = np.uint8(deblocked * 255.)
     
            index = imgName[i].rfind('.')
            name = imgName[i][:index]
            skimage.io.imsave(results_path + name +'.png', deblocked)             
            print('%d / %d images processed' % (i+1, num_imgs))
            
   sess.close()   
   
   plt.subplot(1,2,1)     
   plt.imshow(ori[0,:,:,0])          
   plt.title('Compressed')
   plt.subplot(1,2,2)    
   plt.imshow(deblocked)
   plt.title('De-blocked')
   plt.show()        