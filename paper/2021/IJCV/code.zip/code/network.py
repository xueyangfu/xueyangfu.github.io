# This is the testing code of our IJCV paper and for non-commercial use only. 
# Xueyang Fu, Qi Qi, Zheng-Jun Zha, Xinghao Ding, Feng Wu, John Paisley. "Successive Graph Convolutional Network for Image De-raining", International Journal of Computer Vision, 2021.


import tensorflow as tf


def ReLU(x):
    out = tf.nn.relu(x)    
    return  out 


def ConvLSTM(F,h,c):        
    with tf.variable_scope('ConvLSTM'):
        F = tf.concat([F,h],-1)
        _, _, _, in_channels = F.get_shape().as_list()
    
        i = tf.layers.conv2d(F, in_channels//2, 3, padding = 'same', activation = tf.nn.sigmoid)
        f = tf.layers.conv2d(F, in_channels//2, 3, padding = 'same', activation = tf.nn.sigmoid)
        o = tf.layers.conv2d(F, in_channels//2, 3, padding = 'same', activation = tf.nn.sigmoid)
        g = tf.layers.conv2d(F, in_channels//2, 3, padding = 'same', activation = tf.nn.tanh)
        c = f * c + i * g
        h = o * tf.nn.tanh(c)
        F = h    
        
    return F,h,c



def SpatialBlock(input_tensor):
    _, _, _, in_channels = input_tensor.get_shape().as_list()    
  
    channels = in_channels//2
    
    with tf.variable_scope('spatial'):
        
        theta = tf.layers.conv2d(input_tensor, channels, 1, padding="valid")
        theta = tf.reshape(theta, shape=[-1, tf.shape(input_tensor)[1] * tf.shape(input_tensor)[2], channels])
    
        nu =  tf.layers.conv2d(input_tensor, channels, 1, padding="valid")
        nu =  tf.reshape(nu, shape=[-1, tf.shape(input_tensor)[1] * tf.shape(input_tensor)[2], channels])
    
        xi =  tf.layers.conv2d(input_tensor, channels, 1, padding="valid")
        xi =  tf.reshape(xi, shape=[-1, tf.shape(input_tensor)[1] * tf.shape(input_tensor)[2], channels])
    
    
        nu_tmp = tf.reshape(nu, shape=[-1,  tf.shape(nu)[1] *  tf.shape(nu)[2]])    
        nu_tmp = tf.nn.softmax(nu_tmp, axis=-1)
        nu_tmp = tf.reshape(nu_tmp, shape=[-1, tf.shape(nu)[1],  tf.shape(nu)[2]])   
    
        xi_tmp = tf.reshape(xi, shape=[-1,  tf.shape(xi)[1] *  tf.shape(xi)[2]])    
        xi_tmp = tf.nn.softmax(xi_tmp, axis=-1)
        xi_tmp = tf.reshape(xi_tmp, shape=[-1, tf.shape(xi)[1],  tf.shape(xi)[2]])     
    
    
        AF = tf.matmul( theta, tf.matmul(nu_tmp, xi_tmp, transpose_a=True) )
    
    
        output = tf.reshape(AF, shape=[-1,  tf.shape(input_tensor)[1],  tf.shape(input_tensor)[2], channels])
        output = tf.layers.conv2d(output, in_channels, 1, padding='valid')   
        
    return output



def ChannelBlock(input_tensor):
    _, _, _, channels = input_tensor.get_shape().as_list()    

    D = channels//3
    N = channels//2
  
    with tf.variable_scope('channel'):
        kappa = tf.layers.conv2d(input_tensor, N, 1, padding="valid")
        kappa = tf.reshape(kappa, shape=[-1, tf.shape(input_tensor)[1] * tf.shape(input_tensor)[2], N])
        
        zeta = tf.layers.conv2d(input_tensor, D, 1, padding="valid")    
        zeta =  tf.reshape(zeta, shape=[-1, tf.shape(input_tensor)[1] * tf.shape(input_tensor)[2], D])
        
        F_c = tf.matmul(kappa, zeta, transpose_a = True)
    
        tmp_1 = tf.reshape(F_c, shape=[-1,  N * D])    
        tmp_1 = tf.nn.softmax(tmp_1, axis=-1)
        F_c = tf.reshape(tmp_1, shape=[-1, N,  D]) 
    
        tmp_2 = tf.transpose(F_c,perm=(0,2,1))
        AF =  tf.layers.conv1d(tmp_2, N, 1, padding="valid")
        AF = tf.transpose(AF,perm=(0,2,1))
        F_AFW =  F_c + tf.layers.conv1d(AF, D, 1, padding="valid")
    
    
        output = tf.matmul(kappa, F_AFW)
        output = tf.reshape(output, shape=[-1,  tf.shape(input_tensor)[1],  tf.shape(input_tensor)[2], D])
        output = tf.layers.conv2d(output, channels, 1, padding="valid")

    return output



def DilatedBlock(images):
    with tf.variable_scope('DilatedBlock'):
        _, _, _, channels = images.get_shape().as_list()      
             
        conv1_1 = tf.layers.conv2d(images, channels, 3, dilation_rate=(1, 1), padding="SAME", activation = ReLU)
        conv1_2 = tf.layers.conv2d(conv1_1, channels, 3, dilation_rate=(1, 1), padding="SAME", activation = ReLU)

        conv3_1 = tf.layers.conv2d(images, channels, 3, dilation_rate=(3, 3), padding="SAME", activation = ReLU)
        conv3_2 = tf.layers.conv2d(conv3_1, channels, 3, dilation_rate=(3, 3), padding="SAME", activation = ReLU)

        Concat11 = tf.concat([conv1_1, conv1_2, conv3_1, conv3_2],-1)
        output = tf.layers.conv2d(Concat11, channels, 1, padding = 'valid')

    return output




def Network(image, stage = 5, num_fea = 18):   
    images_t = image
  
    for t in range(stage):
      
        inputs = tf.concat([images_t,image],-1)   
   
        with tf.variable_scope('inference', reuse=tf.AUTO_REUSE):    
             basic = tf.layers.conv2d(inputs, num_fea, 3, padding = 'same', activation = ReLU)
             
             with tf.variable_scope('unit_1'):         
                 dilatedblock = DilatedBlock(basic)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block1 = ReLU(channelblock + spatialblock + dilatedblock + basic)
        
             with tf.variable_scope('unit_2'):         
                 dilatedblock = DilatedBlock(block1)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block2 = ReLU(channelblock + spatialblock + dilatedblock + block1)
        
             with tf.variable_scope('unit_3'):         
                 dilatedblock = DilatedBlock(block2)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block3 = ReLU(channelblock + spatialblock + dilatedblock + block2)
        
             with tf.variable_scope('unit_4'):         
                 dilatedblock = DilatedBlock(block3)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block4 = ReLU(channelblock + spatialblock + dilatedblock + block3)
        
             with tf.variable_scope('unit_5'):         
                 dilatedblock = DilatedBlock(block4)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block5 = ReLU(channelblock + spatialblock + dilatedblock + block4)
        
             with tf.variable_scope('unit_6'):         
                 dilatedblock = DilatedBlock(block5)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block6 = ReLU(channelblock + spatialblock + dilatedblock + block5)
        
             with tf.variable_scope('unit_7'):         
                 dilatedblock = DilatedBlock(block6)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block7 = ReLU(channelblock + spatialblock + dilatedblock + block6)
        
             with tf.variable_scope('unit_8'):         
                 dilatedblock = DilatedBlock(block7)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block8 = ReLU(channelblock + spatialblock + dilatedblock + block7)
     
             with tf.variable_scope('unit_9'):         
                 dilatedblock = DilatedBlock(block8)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block9 = ReLU(channelblock + spatialblock + dilatedblock + block8)
        
             with tf.variable_scope('unit_10'):         
                 dilatedblock = DilatedBlock(block9)
                 channelblock =  ChannelBlock(dilatedblock)
                 spatialblock =  SpatialBlock(dilatedblock)
                 block10 = ReLU(channelblock + spatialblock + dilatedblock + block9)     
        
             with tf.variable_scope('convLSTM'):   
               LSTM_feat =  block10
               if t==0:
                 h = tf.zeros_like(LSTM_feat)
                 c = tf.zeros_like(LSTM_feat)
               LSTM_feat,h,c = ConvLSTM(LSTM_feat,h,c)  
        
             with tf.variable_scope('reconstruction'):   
                 res  = tf.layers.conv2d(LSTM_feat, 3, 3, padding = 'same', activation = tf.nn.tanh)     
                 output = image + res
         
        images_t = output     
     
    return  output