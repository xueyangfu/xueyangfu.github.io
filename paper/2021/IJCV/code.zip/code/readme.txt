This is the testing code of our IJCV paper [1] and for non-commercial use only. You need to install Python with Tensorflow-GPU to run this code.

We have fine-tuned the code to generate better de-raining results than those reported in the paper.

If this code helps your research, please cite our paper:

[1] Xueyang Fu, Qi Qi, Zheng-Jun Zha, Xinghao Ding, Feng Wu, John Paisley. "Successive Graph Convolutional Network for Image De-raining", International Journal of Computer Vision, 2021.
