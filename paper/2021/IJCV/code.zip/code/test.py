# This is the testing code of our IJCV paper and for non-commercial use only. 
# Xueyang Fu, Qi Qi, Zheng-Jun Zha, Xinghao Ding, Feng Wu, John Paisley. "Successive Graph Convolutional Network for Image De-raining", International Journal of Computer Vision, 2021.

import os
import skimage.io
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

import network


os.environ["CUDA_VISIBLE_DEVICES"] = "0"

tf.reset_default_graph()


model_path = './model/model-200H'  # the path of trained model


input_path = "./TestImg/rainy/"  # the path of rainy images
results_path ='./TestImg/results/'  # the path of de-rained images



def _parse_function(filename):     
  image_string = tf.read_file(filename)  
  image_decoded = tf.image.decode_png(image_string, channels = 3)  
  img = tf.cast(image_decoded, tf.float32)/255.
  return img 



if __name__ == '__main__':
   imgName = os.listdir(input_path)
   filename = os.listdir(input_path)
   for i in range(len(filename)):
      filename[i] = input_path + filename[i]
      
      
   filename_tensor = tf.convert_to_tensor(filename, dtype=tf.string)  
   dataset = tf.data.Dataset.from_tensor_slices(filename_tensor)
   dataset = dataset.map(_parse_function)    
   dataset = dataset.prefetch(buffer_size = 10)
   dataset = dataset.batch(1).repeat()  
   iterator = dataset.make_one_shot_iterator()   
   rain = iterator.get_next()    
 

   output = network.Network(rain)
   output = tf.clip_by_value(output[0,:,:,:], 0., 1.)

   all_vars = tf.trainable_variables()  
   config = tf.ConfigProto()
   config.gpu_options.allow_growth = True   
   saver = tf.train.Saver()


   iterations = len(filename)   
   with tf.Session(config=config) as sess:

      with tf.device('/gpu:0'): 
        saver.restore(sess, model_path)
        print ("Loading model")

        for i in range(iterations):
     
            derained,ori = sess.run([output,rain])              
            derained = np.uint8(derained * 255.)
            index = imgName[i].rfind('.')
            name = imgName[i][:index]
            skimage.io.imsave(results_path + name +'_derained.png', derained)         
            print('%d / %d images processed' % (i+1,iterations))
              
        print("Finished, total parameters number: %d" 
              %(np.sum([np.prod(v.get_shape().as_list()) for v in all_vars])))  
      
   sess.close()   
   
   plt.subplot(1,2,1)     
   plt.imshow(ori[0,:,:,:])          
   plt.title('rainy')
   plt.subplot(1,2,2)    
   plt.imshow(derained)
   plt.title('derained')
   plt.show()        