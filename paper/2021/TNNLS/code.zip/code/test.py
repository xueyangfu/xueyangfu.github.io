#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# This is a implementation of testing code (Tensorflow 1.13.1) of this paper:
# X. Fu, M. Wang, X. Cao, X. Ding, Z.-J. Zha. “A Model-Driven Deep Unfolding Method for JPEG Artifacts Removal”, IEEE T-NNLS, 2021.


import os
import skimage.io
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

import model

tf.reset_default_graph()


input_path = './img/JPEG/'      # the path of testing images
results_path = './img/Output/'  # the path of output images


def _parse_function(filename):  
   image_string = tf.read_file(filename)  
   image_decoded = tf.image.decode_jpeg(image_string, channels = 1)  
   JPEG = tf.cast(image_decoded, tf.float32)/255.0
   return JPEG 


if __name__ == '__main__':
   
   filename = os.listdir(input_path)
   for i in range(len(filename)):
       filename[i] = input_path + filename[i]  
   filename_tensor = tf.convert_to_tensor(filename, dtype=tf.string)  

   dataset = tf.data.Dataset.from_tensor_slices((filename_tensor))
   dataset = dataset.map(_parse_function)    
   dataset = dataset.prefetch(buffer_size= 10)
   dataset = dataset.batch(1).repeat()  
   iterator = dataset.make_one_shot_iterator()
   
   Input = iterator.get_next()    
 
   Output = model.Unfolding(Input)
 
   Output = tf.clip_by_value(Output[0,:,:,0], 0., 1.)

   config = tf.ConfigProto()
   config.gpu_options.allow_growth=True
   
   with tf.Session(config=config) as sess:
        var_ = [var for var in tf.trainable_variables()  if 'Inference' in var.name]     
        saver = tf.train.Saver(var_list = var_)
        saver.restore(sess,'model')     
        print ("Loading model")
        
        
        imgName = os.listdir(input_path)
        num_img = len(filename)
        for i in range(num_img):
     
            deblocked,ori = sess.run([Output,Input])              
            deblocked = np.uint8(deblocked * 255.)
     
            index = imgName[i].rfind('.')
            name = imgName[i][:index]
            skimage.io.imsave(results_path + name +'.png', deblocked) 
            print('%d / %d images processed' % (i+1,num_img))            
            
   sess.close()   
   
   plt.subplot(1,2,1)     
   plt.imshow(ori[0,:,:,0])          
   plt.title('JPEG')
   plt.subplot(1,2,2)    
   plt.imshow(deblocked)
   plt.title('Output')
   plt.show()        