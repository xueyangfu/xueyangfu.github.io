#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# This is a implementation of testing code (Tensorflow 1.13.1) of this paper:
# X. Fu, M. Wang, X. Cao, X. Ding, Z.-J. Zha. “A Model-Driven Deep Unfolding Method for JPEG Artifacts Removal”, IEEE T-NNLS, 2021.


import tensorflow as tf

def prox_M(image):
    with tf.variable_scope('proxM'):           
        inchannels = image.get_shape().as_list()[-1]              
        num_features  =  inchannels//2       
        conv = tf.layers.conv2d(image, num_features, 3, padding="same", activation = tf.nn.relu)      
        for i in range(5):          
            with tf.variable_scope('iteration_%d'% (i + 1)):           
                conv_1 = tf.layers.conv2d(conv, num_features, 3, padding="same", activation = tf.nn.relu)
                conv_2 = tf.layers.conv2d(conv_1, num_features, 3, padding="same", activation = tf.nn.relu)  
                conv = conv + conv_2       
        out = tf.layers.conv2d(conv, inchannels, 3, padding = 'SAME')                   
    return out


def prox_O(image,num_features):
    with tf.variable_scope('proxO'):          
        inchannels = image.get_shape().as_list()[-1]         
        conv = tf.layers.conv2d(image, num_features, 3, padding="same", activation = tf.nn.relu)
        for i in range(5):          
            with tf.variable_scope('iteration_%d'% (i + 1)):   
                conv_1 = tf.layers.conv2d(conv, num_features, 3, padding="same", activation = tf.nn.relu)
                conv_2 = tf.layers.conv2d(conv_1, num_features, 3, padding="same", activation = tf.nn.relu)  
                conv = conv + conv_2        
        out = tf.layers.conv2d(conv, inchannels, 3, padding = 'SAME')     
        B = out[:,:,:,0:1]
        Z = out[:,:,:,1:inchannels]        
    return B, Z


def Unfolding(J, num_features = 48, iterations = 10): 
    with tf.variable_scope("Inference", reuse=tf.AUTO_REUSE):  
        
        with tf.variable_scope('initial'):   # initial
            O_0 = tf.layers.conv2d(J, num_features, 3, padding="same")           
            tmp = tf.concat([O_0,J],-1)
            O_previous, Z = prox_O(tmp,num_features)       
            H = J - O_previous   
                
        with tf.variable_scope('iteration0'):  # iteration 1         
            X_1 = tf.layers.conv2d(H, num_features, 3, dilation_rate=(1, 1), padding="same", name = 'X1', use_bias = False)    
            X_2 = tf.layers.conv2d(H, num_features, 3, dilation_rate=(2, 2), padding="same", name = 'X2', use_bias = False)               
            X_4 = tf.layers.conv2d(H, num_features, 3, dilation_rate=(4, 4), padding="same", name = 'X4', use_bias = False)            
      
            M = prox_M(tf.concat([X_1, X_2, X_4],-1))
       
            X_1 = tf.layers.conv2d(M[:,:,:,0:num_features], num_features, 3, dilation_rate=(1, 1), padding="same", name = 'X11', use_bias = False)    
            X_2 = tf.layers.conv2d(M[:,:,:,num_features:num_features*2], num_features, 3, dilation_rate=(2, 2), padding="same", name = 'X22', use_bias = False)             
            X_4 = tf.layers.conv2d(M[:,:,:,num_features*2:num_features*3], num_features, 3, dilation_rate=(4, 4), padding="same", name = 'X44', use_bias = False)
            
            h_current =  tf.concat([X_1,X_2,X_4],-1) 
            H_current = tf.reduce_sum(h_current,axis=-1, keepdims = True)  
       
            O_current = J - H_current        
            stepO = tf.get_variable('stepO', initializer = tf.constant(0.1), trainable= True)          
            tmp = tf.concat([Z, stepO * O_current + (1. - stepO) * O_previous],-1)
            
            O_current, Z = prox_O(tmp, num_features)             

    
        for i in range(iterations - 1):   # iterations 2 to 10            
            with tf.variable_scope('iteration_%d'% (i + 1)):               
               O_previous = O_current       
               H = J - O_previous

               X_1 = tf.layers.conv2d(M[:,:,:,0:num_features], num_features, 3, dilation_rate=(1, 1), padding="same", name = 'X11', use_bias = False)  
               X_2 = tf.layers.conv2d(M[:,:,:,num_features:num_features*2], num_features, 3, dilation_rate=(2, 2), padding="same", name = 'X22', use_bias = False)           
               X_4 = tf.layers.conv2d(M[:,:,:,num_features*2:num_features*3], num_features, 3, dilation_rate=(4, 4), padding="same", name = 'X44', use_bias = False)
               
               H_star = tf.concat([X_1,X_2,X_4],-1) 
               H_star = tf.reduce_sum(H_star, axis=-1, keepdims = True)  
                   
               X_1 = tf.layers.conv2d(H_star-H, num_features, 3, dilation_rate=(1, 1), padding="same", name = 'X1', use_bias = False)  
               X_2 = tf.layers.conv2d(H_star-H, num_features, 3, dilation_rate=(2, 2), padding="same", name = 'X2', use_bias = False)            
               X_4 = tf.layers.conv2d(H_star-H, num_features, 3, dilation_rate=(4, 4), padding="same", name = 'X4', use_bias = False)               

               stepM = tf.get_variable('stepM', initializer=tf.constant(0.1), trainable= True)                     
               M = prox_M(M - stepM * tf.concat([X_1, X_2, X_4],-1))

               X_1 = tf.layers.conv2d(M[:,:,:,0:num_features], num_features, 3, dilation_rate=(1, 1), padding="same", name = 'X111', use_bias = False)    
               X_2 = tf.layers.conv2d(M[:,:,:,num_features:num_features*2], num_features, 3, dilation_rate=(2, 2), padding="same", name = 'X222', use_bias = False)             
               X_4 = tf.layers.conv2d(M[:,:,:,num_features*2:num_features*3], num_features, 3, dilation_rate=(4, 4), padding="same", name = 'X444', use_bias = False)
               
               h_current = tf.concat([X_1,X_2,X_4],-1) 
               H_current = tf.reduce_sum(h_current, axis=-1, keepdims = True)  

               O_current = J - H_current        
               stepO = tf.get_variable('stepO', initializer = tf.constant(0.1), trainable= True)              
               tmp = tf.concat([Z, stepO * O_current + (1. - stepO) * O_previous],-1)
               O_current, Z = prox_O(tmp, num_features)  
               
        final_out = O_current
        return final_out
