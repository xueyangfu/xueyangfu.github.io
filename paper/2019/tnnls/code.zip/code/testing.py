#!/usr/bin/env python2
# -*- coding: utf-8 -*-


# This is a implementation of testing code of this paper:
# X. Fu, B. Liang, Y. Huang, X. Ding and J. Paisley. “Lightweight Pyramid Networks for Image Deraining”, arXiv preprint arXiv:1805.06173, 2018.
# author: Xueyang Fu (xyfu@ustc.edu.cn)

import os
import skimage
import numpy as np
import tensorflow as tf
import matplotlib.image as img
import matplotlib.pyplot as plt


import model

tf.reset_default_graph()

model_path = './model/'
pre_trained_model_path = './model/pre_trained/light_model'  # 'heavy_model' for Rain100H,  'light_model' for Rain100L


img_path = './test_img/rain/' # the path of testing images

files_rainy = os.listdir(img_path)
num = len(files_rainy)


tensor_input = tf.placeholder(tf.float32, shape=(1, None, None, 3))

outout_pyramid = model.inference(tensor_input)


saver = tf.train.Saver()
config = tf.ConfigProto(device_count = {'GPU': 0}) 

with tf.Session(config=config) as sess:

  if tf.train.get_checkpoint_state(model_path):  
     ckpt = tf.train.latest_checkpoint(model_path)  # try your own model 
     saver.restore(sess, ckpt)
     print ("Loading model")
  else:
     saver.restore(sess, pre_trained_model_path) # try a pre-trained model 
     print ("Loading pre-trained model")
           
           
  for i in range(num):    

    ori = img.imread(img_path + files_rainy[i])
    if np.max(ori) > 1:
       ori = ori[:,:,0:3]
       ori = ori/255.0
    
    input1 = np.expand_dims(ori[:,:,:], axis = 0)

    out  = sess.run(outout_pyramid, feed_dict={tensor_input:input1})

    derained = out[4]
    derained[np.where(derained < 0. )] = 0.
    derained[np.where(derained > 1. )] = 1.
    
    derained = derained[0,:,:,:] * 255.
    derained = np.uint8(derained)

    index = files_rainy[i].rfind('.')
    name = files_rainy[i][:index]
    skimage.io.imsave('./test_img/results/' + name +'_derained.png', derained)         
    print('%d / %d images processed' % (i+1,num))
    
sess.close()    

plt.subplot(1,2,1)     
plt.imshow(ori)      
plt.title('rainy')
plt.subplot(1,2,2)    
plt.imshow(derained)
plt.title('derained')
plt.show()