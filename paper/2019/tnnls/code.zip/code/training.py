#!/usr/bin/env python2
# -*- coding: utf-8 -*-


# This is a implementation of training code of this paper:
# X. Fu, B. Liang, Y. Huang, X. Ding and J. Paisley. “Lightweight Pyramid Networks for Image Deraining”, arXiv preprint arXiv:1805.06173, 2018.
# author: Xueyang Fu (xyfu@ustc.edu.cn)


import os
import re
import time
import random
import numpy as np
import tensorflow as tf
import matplotlib.image as img
import matplotlib.pyplot as plt


from model import inference, GaussianPyramid 


os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"



num_pyramids = 5       # number of pyramid levels
learning_rate = 1e-3   # learning rate
iterations = int(3e5)  # iterations
batch_size = 10        # batch size
num_channels = 3       # number of input's channels 
patch_size = 80        # patch size 
save_model_path = './model/'  # path of saved model
model_name = 'model-epoch'    # name of saved model


input_path = './TrainData/input/' # rainy images
gt_path = './TrainData/label/'    # ground truth
inputfiles = os.listdir(input_path)
gtfiles = os.listdir(gt_path)  



# randomly select image patches
def read_data(input_path, gt_path, inputfiles, gtfiles, patch_size, batch_size):   
    Data =  np.zeros((batch_size, patch_size, patch_size, 3)) 
    Label = np.zeros((batch_size, patch_size, patch_size, 3)) 
  
    for i in range(batch_size):
  
        r_idx = random.randint(0,len(inputfiles)-1)
    
        rainy = img.imread(input_path + inputfiles[r_idx])
        if np.max(rainy) > 1:
           rainy = rainy/255.0

        label = img.imread(gt_path + gtfiles[r_idx])
        if np.max(label) > 1:
           label = label/255.0

        x = random.randint(0,rainy.shape[0] - patch_size)
        y = random.randint(0,rainy.shape[1] - patch_size)

        subim_input = rainy[x : x+patch_size, y : y+patch_size, :]
        subim_label = label[x : x+patch_size, y : y+patch_size, :]

        Data[i,:,:,:] = subim_input
        Label[i,:,:,:] = subim_label

    return Data, Label



if __name__ == '__main__':
    
  tf.reset_default_graph()
  
  images = tf.placeholder(tf.float32, shape=(batch_size, patch_size, patch_size, num_channels)) 
  labels = tf.placeholder(tf.float32, shape=(batch_size, patch_size, patch_size, num_channels))  

  k = np.float32([.0625, .25, .375, .25, .0625])  # Gaussian kernel for image pyramid
  k = np.outer(k, k) 
  kernel = k[:,:,None,None]/k.sum()*np.eye(3, dtype = np.float32)
  labels_GaussianPyramid = GaussianPyramid( labels, kernel, (num_pyramids-1) ) # Gaussian pyramid for ground truth


  outout_pyramid = inference(images) # LPNet


  loss1 = tf.reduce_mean(tf.abs(outout_pyramid[0] - labels_GaussianPyramid[0]))    # L1 loss
  loss2 = tf.reduce_mean(tf.abs(outout_pyramid[1] - labels_GaussianPyramid[1]))    # L1 loss
  loss3 = tf.reduce_mean(tf.abs(outout_pyramid[2] - labels_GaussianPyramid[2]))    # L1 loss
  
  loss41 = tf.reduce_mean(tf.abs(outout_pyramid[3] - labels_GaussianPyramid[3]))   # L1 loss
  loss42 = tf.reduce_mean((1. - tf.image.ssim(outout_pyramid[3],labels_GaussianPyramid[3], max_val=1.0))/2.) # SSIM loss

  loss51 = tf.reduce_mean(tf.abs(outout_pyramid[4] - labels))  # L1 loss
  loss52 = tf.reduce_mean((1. - tf.image.ssim(outout_pyramid[4],labels, max_val=1.0))/2.) # SSIM loss
    
  loss = loss1 + loss2 + loss3 + loss41 + loss42 + loss51 + loss52
  g_optim =  tf.train.AdamOptimizer(learning_rate).minimize(loss) # Optimization method: Adam
  
  
  all_vars = tf.trainable_variables()  
  saver = tf.train.Saver(var_list=all_vars, max_to_keep = 5)  

 
  Check_data, Check_label = read_data(input_path, gt_path, inputfiles, gtfiles, patch_size, batch_size)  
  print("Check patch pair")  
  plt.subplot(1,2,1)     
  plt.imshow(Check_data[0,:,:,:])     
  plt.title('rainy')
  plt.subplot(1,2,2)    
  plt.imshow(Check_label[0,:,:,:])   
  plt.title('ground truth')  
  plt.show()

  
  config = tf.ConfigProto()
  config.gpu_options.allow_growth=True
  with tf.Session(config=config) as sess:
      
       sess.run(tf.group(tf.global_variables_initializer(), 
                         tf.local_variables_initializer()))
	
       if tf.train.get_checkpoint_state(save_model_path):   # load previous trained model 
          ckpt = tf.train.latest_checkpoint(save_model_path)
          saver.restore(sess, ckpt)  
          ckpt_num = re.findall(r'(\w*[0-9]+)\w*',ckpt)
          start_point = int(ckpt_num[0])     
          print("Load success")

       else:  # re-training when no models found
          print("re-training")
          start_point = 0     

     
       start = time.time()    
       
       for j in range(start_point,iterations):
           train_data, train_label = read_data(input_path, gt_path, inputfiles, gtfiles, patch_size, batch_size)
           _, Training_Loss = sess.run([g_optim,loss], feed_dict={images: train_data, labels: train_label})  # training

           if np.mod(j+1,100) == 0 and j != 0:    
              end = time.time() 
              print ('%d / %d iteraions, Training Loss  = %.4f, running time = %.1f s' 
                     % (j+1, iterations, Training_Loss, (end-start)))          
              save_path_full = os.path.join(save_model_path, model_name) 
              saver.save(sess, save_path_full, global_step = j+1) # save model every 100 iterations
              start = time.time()    