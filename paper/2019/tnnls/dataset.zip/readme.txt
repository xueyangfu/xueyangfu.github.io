This is the real-world rainy dataset (300 images) reported in our paper [1] and for non-commercial use only. 

The training code can be found at:  https://xueyangfu.github.io/projects/LPNet.html

If this dataset help your research, please cite our paper:

[1] X. Fu, B. Liang, Y. Huang, X. Ding and J. Paisley. "Lightweight Pyramid Networks for Image Deraining", IEEE Transactions on Neural Networks and Learning Systems, 2019.



