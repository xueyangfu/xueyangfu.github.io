#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# This is the testing code of our paper and for non-commercial use only. 
# X. Fu, Z.-J. Zha, F. Wu, X. Ding and J. Paisley. "JPEG Artifact Reduction via Deep Convolutional Sparse Coding", ICCV, 2019.

import numpy as np
import tensorflow as tf


def MAE_loss(Input, Output):
    return tf.reduce_mean(tf.abs(Input - Output))
	
	
def MSE_loss(Input, Output):
    return tf.reduce_mean(tf.square(Input - Output))



def optimazation(G_X,iterations): 
    
    U = tf.nn.relu(G_X)    
    _, _, _, channels = G_X.get_shape().as_list() 

    for _ in range(iterations):
        S_U = tf.layers.conv2d(U, channels, 3, padding = 'same', name='S_U', use_bias=False)              
        U = tf.nn.relu(G_X + S_U)

    return U


def Network(J, num_features, iterations):         
    
     _, _, _, channels = J.get_shape().as_list() 
     
     with tf.variable_scope("DCSC", reuse=tf.AUTO_REUSE):
              
       with tf.variable_scope('X'):    
            X_1 = tf.layers.conv2d(J, 32, 3, dilation_rate=(1, 1), padding="SAME", name = 'X1')    
            X_2 = tf.layers.conv2d(J, 32, 3, dilation_rate=(2, 2), padding="SAME", name = 'X2')               
            X_4 = tf.layers.conv2d(J, 32, 3, dilation_rate=(4, 4), padding="SAME", name = 'X4')                     
            X =  tf.concat([X_1,X_2,X_4],3)
            
       with tf.variable_scope('G_X'):   
            G_X = tf.layers.conv2d(X, num_features, 3, padding = 'same', name = 'G_X', use_bias=False)
          
       with tf.variable_scope('optimization'):            
            U = optimazation(G_X, iterations)
               
       with tf.variable_scope('recons'):        
            H  = tf.layers.conv2d(U, channels, 3, padding = 'same', name = 'residual')               
            O = J + H
            
     return  O


def inference(J, num_features = 64, iterations = 40):
    
  with tf.variable_scope('inference', reuse=tf.AUTO_REUSE):  
      
    O = Network(J, num_features, iterations)
      
  return O

   
if __name__ == '__main__':
    tf.reset_default_graph()      
    
    Input = tf.random_normal([16,64,64,1])
    
    Output = inference(Input)

    all_vars = tf.trainable_variables()       
    g_vars = [var for var in all_vars if 'DCSC' in var.name]
    print("Trainable parameter numbers: %d" %(np.sum([np.prod(v.get_shape().as_list()) for v in g_vars])))     