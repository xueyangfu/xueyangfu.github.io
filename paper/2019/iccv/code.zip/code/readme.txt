This is the testing code of our paper [1] and for non-commercial use only. 

You need to install Python with Tensorflow-GPU to run this code.


We have increased the model capacity and retrained the network which can cover four JPEG qualities.


Usage:


1. Run "testing.py" to test new images, the reuslts should be generated at "/data/results". 

2. Our new single pretrained model is able to handle four JPEG qualities (10, 20, 30 and 40).

3. To train your own model, you can modify the training code at:  https://xueyangfu.github.io/projects/LPNet.html


If this code helps your research, please cite our paper:

[1] X. Fu, Z.-J. Zha, F. Wu, X. Ding and J. Paisley. "JPEG Artifact Reduction via Deep Convolutional Sparse Coding", ICCV, 2019.






