#!/usr/bin/env python2
# -*- coding: utf-8 -*-

# This is the testing code of our paper and for non-commercial use only. 
# X. Fu, Z.-J. Zha, F. Wu, X. Ding and J. Paisley. "JPEG Artifact Reduction via Deep Convolutional Sparse Coding", ICCV, 2019.


import os
import skimage
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt

from network import DeepCSC



tf.reset_default_graph()

input_path = './data/classic5/q10/'
result_path =  './data/results/'


def _parse_function(filename):  
    image_string = tf.read_file(filename)  
    image_decoded = tf.image.decode_jpeg(image_string, channels=1)  
    images = tf.image.convert_image_dtype(image_decoded, dtype=tf.float32)
    return images 



if __name__ == '__main__':
    imgName = os.listdir(input_path)
    filename = os.listdir(input_path)    
    num_img = len(filename) 
    
    for i in range(num_img):
        filename[i] = input_path + filename[i]
       
    filename_tensor = tf.convert_to_tensor(filename, dtype=tf.string)       
    dataset = tf.data.Dataset.from_tensor_slices((filename_tensor))
    dataset = dataset.map(_parse_function)    
    dataset = dataset.prefetch(buffer_size = 10)
    dataset = dataset.batch(1).repeat()  
    iterator = dataset.make_one_shot_iterator()  
    
    jpeg = iterator.get_next()  
 
    output = DeepCSC(jpeg)    
    output = tf.clip_by_value(output, 0.0, 1.0)
    deblocked = output[0,:,:,0]
   
    config = tf.ConfigProto()
    config.gpu_options.allow_growth=True  
    saver = tf.train.Saver()
   
    with tf.Session(config=config) as sess:
          saver.restore(sess,  './model/model') # try the pre-trained model 
          print ("Loading model")

          for i in range(num_img):     
              final_output, ori = sess.run([deblocked,jpeg])              
              final_output = np.uint8(final_output* 255.)

              index = imgName[i].rfind('.')
              name = imgName[i][:index]
              skimage.io.imsave(result_path + name +'.png', final_output)         
              print('%d / %d images processed' % (i+1,num_img))
              
          print('All finished')
      
    sess.close()   

 
    plt.subplot(1,2,1)     
    plt.imshow(ori[0,:,:,0])          
    plt.title('input')
    plt.subplot(1,2,2)    
    plt.imshow(final_output)
    plt.title('de-blocked')
    plt.show()        