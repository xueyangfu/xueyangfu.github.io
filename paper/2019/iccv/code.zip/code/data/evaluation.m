clc
clear

gt_dir = '.\gt\';
gt_files = dir([gt_dir, '*.bmp']);


deblocked_dir = '.\results\';
deblocked_files = dir([deblocked_dir, '*.png']);

num_img = length(deblocked_files);

psnr_list  = zeros(1, num_img);
ssim_list  = zeros(1, num_img);
psnrb_list  = zeros(1, num_img);


for i = 1 : num_img
    
    deblocked_name = [deblocked_dir, deblocked_files(i).name];
    deblocked = im2double(imread(deblocked_name));

    
    gt_name = [gt_dir, gt_files(i).name];
    gt = im2double(imread(gt_name));    

    
    errors = compute_errors(gt,deblocked);          
    psnr_list(1,i) = errors(1);    
    psnrb_list(1,i) =  errors(2);  
    ssim_list(1,i) =  errors(4);

end

avg_PSNR = mean(psnr_list);
avg_SSIM = mean(ssim_list);
avg_PSNR_B = mean(psnrb_list);

fprintf(' avg_PSNR: %f;\n avg_SSIM: %f;\n avg_PSNR_B: %f;\n\n', avg_PSNR, avg_SSIM, avg_PSNR_B);
