clc
clear

gt_dir = '.\gt\';
gt_files = dir([gt_dir, '*.bmp']);

deblocked_dir = '.\results\';
deblocked_files = dir([deblocked_dir, '*.png']);

num_img = length(deblocked_files);


psnr_res = 0;
ssim_res = 0;
psnrb_res = 0;

psnr_list  = zeros(1, num_img);
ssim_list  = zeros(1, num_img);
psnrb_list  = zeros(1, num_img);


for i = 1 : num_img
    
    deblocked_name = [deblocked_dir, deblocked_files(i).name];
    deblocked = imread(deblocked_name);

    gt_name = [gt_dir, gt_files(i).name];
    gt = imread(gt_name);    
  
    [psnr_value] = compute_psnr(deblocked,gt);
    [ssim_value] = compute_ssim(deblocked,gt,0,0);  
    [psnrb_value] = compute_psnrb(deblocked,gt);
         
    psnr_list(1,i) = psnr_value;
    ssim_list(1,i) = ssim_value;
    psnrb_list(1,i) = psnrb_value;  
    
    psnr_res = psnr_res + psnr_value;
    ssim_res = ssim_res + ssim_value;
    psnrb_res = psnrb_res + psnrb_value;

end

avg_PSNR = psnr_res / num_img
avg_SSIM = ssim_res / num_img
avg_PSNR_B = psnrb_res / num_img
