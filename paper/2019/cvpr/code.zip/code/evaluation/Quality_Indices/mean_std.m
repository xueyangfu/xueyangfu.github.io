load('/home2/lzh/yaogan/result/320_result.mat')
mean_result = [];
std_result  = [];
for method = 1:19
    patch_mean = mean(MatrixResults(:,:,method));
    mean_result = [mean_result; patch_mean];
    
    patch_std = std(MatrixResults(:,:,method),0,1);
    std_result = [std_result ; patch_std];
end