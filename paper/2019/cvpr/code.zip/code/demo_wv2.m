%%% This is the matlab code of our CVPR 2019 paper and for non-commercial use only.
%%% If this code helps your research, please cite our paper:
%%% Xueyang Fu, Zihuang Lin, Yue Huang, Xinghao Ding, "A Variational Pan-Sharpening With Local Gradient Constraints", CVPR 2019.

clear;clc;close all
addpath './local constraint/'
addpath './evaluation/'
addpath './evaluation/Quality_Indices/'

load 'wv2.mat';  % World-View2
                
% Quality Index Blocks
Qblocks_size = 32;

% Cut Final Image
flag_cut_bounds = 0;
dim_cut = 11;

% Threshold values out of dynamic range
thvalues = 0;

% Resize Factor
ratio = 4;

% Radiometric Resolution
L = 11;

patch_mul_LR = imresize(patch_mul_GT,0.25);

for i = 1:size(patch_mul_LR,3)
    bandCoeffs(i) = max(max(patch_mul_LR(:,:,i)));
    ImageMS(:,:,i) = patch_mul_LR(:,:,i) / bandCoeffs(i);
end

ImageP = patch_PAN / max(max(patch_PAN));

%%%%%%%%%%%%%%%% Optimization %%%%%%%%%%%%%%%%%%%%%%%%%%
divK = 4; 
lambda = 0.2;
iterations = 100;

I_guide = guide_wv2(ImageMS,ImageP,divK,lambda,iterations);

for i = 1:size(I_guide, 3)
    I_guide(:,:,i) = I_guide(:,:,i) * bandCoeffs(i);
end
%%%%%%%%%%%%%%%% Optimization %%%%%%%%%%%%%%%%%%%%%%%%%%


[Q_avg_guide, SAM_guide, ERGAS_guide, SCC_GT_guide, Q_guide] = indexes_evaluation(I_guide,patch_mul_GT,ratio,L,Qblocks_size,flag_cut_bounds,dim_cut,thvalues);

th_MSrgb = image_quantile(patch_mul_GT(:,:,[5,3,2]), [0.01 0.99]);

I_fuse = image_stretch(I_guide(:,:,[5,3,2]),th_MSrgb);
subplot(1,2,1), imshow(I_fuse), title('fused result');

I_gt = image_stretch(patch_mul_GT (:,:,[5,3,2]),th_MSrgb);
subplot(1,2,2), imshow(I_gt); title('ground truth');





