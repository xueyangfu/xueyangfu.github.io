clc;
clear all;

input = imread('3.jpg');

output = processing( input );

figure, imshow([input,output])