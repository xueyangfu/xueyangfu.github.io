clc;
clear all;

img = imread('.\images\1.jpg');  
enhanced = process( img );

figure, imshow( img ), title('input');
figure, imshow( enhanced ), title('output');