This is the testing code of our paper [1] and for non-commercial use only. 

You need to install Python with Tensorflow-GPU to run this code.


Usage:

Run "test.py" to test new images, the reuslts should be generated at "/img/output". 

If this code helps your research, please cite our paper:

[1]  Xueyang Fu and Xiangyong Cao, "Underwater image enhancement with global-local networks and compressed-histogram equalization", 
     Signal Processing: Image Communication, 2020. DOI: 10.1016/j.image.2020.115892






