# -*- coding: utf-8 -*-
"""
This is a implementation of testing code of our paper [1] and for non-commercial use only:

[1] Xueyang Fu, Wu Wang, Yue Huang, Xinghao Ding, John Paisley, "Deep multiscale detail networks for multiband spectral image sharpening", IEEE Transactions on Neural Networks and Learning Systems, 2021.

"""

import os
import cv2
import numpy as np
import scipy.io as sio
import tensorflow as tf
import tensorflow.contrib.layers as ly

os.environ['CUDA_VISIBLE_DEVICES'] = '0'


def get_edge(data):  
    rs = np.zeros_like(data)
    N = data.shape[0]
    for i in range(N):
        if len(data.shape)==3:
            rs[i,:,:] = data[i,:,:] - cv2.boxFilter(data[i,:,:],-1,(5,5))
        else:
            rs[i,:,:,:] = data[i,:,:,:] - cv2.boxFilter(data[i,:,:,:],-1,(5,5))
    return rs


def block(Xin, num_spectral = 8, num_fm = 32, reuse=False, weight_decay=2e-5):
    X = ly.conv2d(Xin, num_outputs = num_fm, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          activation_fn = tf.nn.relu)
    
    X1, X2, X3, X4 = tf.split(X, [8,8,8,8], axis=3)
    X1 =ly.conv2d(X1, num_outputs = num_fm/4, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          rate = 1, activation_fn = tf.nn.relu)
    X1 =ly.conv2d(X1, num_outputs = num_fm/4, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          rate = 1, activation_fn = None)
    X2 = ly.conv2d(X2, num_outputs = num_fm/4, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          rate = 2, activation_fn = tf.nn.relu)
    X2 = ly.conv2d(X2, num_outputs = num_fm/4, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          rate = 2, activation_fn = None)
    X3 = ly.conv2d(X3, num_outputs = num_fm/4, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          rate = 3, activation_fn = tf.nn.relu)
    X3 = ly.conv2d(X3, num_outputs = num_fm/4, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          rate = 3, activation_fn = None)
    X4 = ly.conv2d(X4, num_outputs = num_fm/4, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          rate = 4, activation_fn = tf.nn.relu)
    X4 = ly.conv2d(X4, num_outputs = num_fm/4, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          rate = 4, activation_fn = None)
    
    X = tf.concat([X1, X2, X3, X4], axis=3)
    X = tf.nn.relu(X)
    
    X = ly.conv2d(X, num_outputs = num_fm, kernel_size = 1, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),
                          activation_fn = None)
    return X


def Network(ms_hp, pan_hp, num_spectral = 8, num_res = 8, num_fm = 32, reuse=False):
    
    weight_decay = 2e-5
    with tf.variable_scope('net'):        
        if reuse:
            tf.get_variable_scope().reuse_variables()
        
        lms_hp = ly.conv2d_transpose(ms_hp, num_spectral,8,4,activation_fn = None,
                                   weights_initializer = ly.variance_scaling_initializer(), 
                                   weights_regularizer = ly.l2_regularizer(weight_decay))
        Xin = tf.concat([pan_hp, lms_hp], axis=3)
        rs = ly.conv2d(Xin, num_outputs = num_fm, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),activation_fn = tf.nn.relu)
        
        for i in range(num_res):
            rs1 = block(rs)
            rs = tf.add(rs,rs1)
        
        rs = ly.conv2d(rs, num_outputs = num_spectral, kernel_size = 3, stride = 1, 
                          weights_regularizer = ly.l2_regularizer(weight_decay), 
                          weights_initializer = ly.variance_scaling_initializer(),activation_fn = None)

        return rs
   

        

if __name__=='__main__':
    
    test_data = sio.loadmat('./Data/TestData.mat')
    LMS_data = test_data['LMS']
    Pan_data = test_data['Pan']
    MS_data  = test_data['MS']    
    
    batch_size = 1
    image_size = 400
    
    tf.reset_default_graph()
      
    ms_holder  = tf.placeholder(dtype = tf.float32,shape = [batch_size, image_size//4, image_size//4,8])
    lms_holder = tf.placeholder(dtype = tf.float32,shape = [batch_size, image_size, image_size,8])
    pan_holder = tf.placeholder(dtype = tf.float32,shape = [batch_size, image_size, image_size,1])
    

    output = Network(ms_holder, pan_holder) + lms_holder  
    output = tf.clip_by_value(output,0.,1.) # final output  
    
    config = tf.ConfigProto()
    config.gpu_options.allow_growth = True
    sess = tf.Session(config=config)
    init = tf.global_variables_initializer()
    saver = tf.train.Saver()
    
    net_out = np.zeros(shape = [10, 400, 400, 8], dtype = np.float32)
    ms_out  = np.zeros(shape = [10, 100, 100, 8], dtype = np.float32)
    pan_out = np.zeros(shape = [10, 400, 400], dtype = np.float32)


    with tf.Session() as sess:  
        sess.run(init)
        
        coord = tf.train.Coordinator()
        threads = tf.train.start_queue_runners(coord=coord)
        
        var = [var for var in tf.trainable_variables()  if 'net' in var.name]     
        saver = tf.train.Saver(var_list = var)
        saver.restore(sess,'./TrainedModel/model.ckpt')        
        
                              
        for i in range(MS_data.shape[0]):
            
            print(i+1)
            
            pan = Pan_data[i,:,:]              
            pan = np.squeeze(pan, axis=-1)
            pan = np.expand_dims(pan, axis=0)
            pan_hp = get_edge(pan)
            pan_hp = np.expand_dims(pan_hp, axis=-1)  
           
            ms = MS_data[i,:,:,:]            
            ms = np.expand_dims(ms, axis=0)            
            ms_hp = get_edge(ms)
            
            lms = LMS_data[i,:,:,:]              
            lms = np.expand_dims(lms, axis=0)

            out = sess.run([output], feed_dict = {pan_holder: pan_hp, ms_holder: ms_hp, lms_holder: lms})
            
            net_out[i,:,:,:] = np.array(out, dtype= np.float32)           
         

        coord.request_stop()
        coord.join(threads)
        sess.close()
        sio.savemat('./Results/Output.mat', {'Output':net_out})