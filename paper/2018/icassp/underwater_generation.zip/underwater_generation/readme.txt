This is the Matlab implementation of our paper [1] for synthesizing underwater images.

If this code helps your research, please cite the related papers:

[1] X. Yu, X. Xing, H. Zheng, X. Fu, Y. Huang and X. Ding. "Man-made object recognition from underwater optical images using deep learning and transfer learning", ICASSP, 2018.

[2] R. M. H. Nguyen, S. J. Kim, and M. S. Brown. "Illuminant Aware Gamut-Based Color Transfer, The Eurographs", Computer Graphics Forum, 2014.


Welcome to our homepage:   https://xmu-smartdsp.github.io/



