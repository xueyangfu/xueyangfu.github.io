clc
clear

input = im2double(imread('.\img\clean.jpg'));             % clean image
underwater = im2double(imread('.\img\water.jpg'));        % target underwater image

color = color_transfer(input, underwater);   % color transfer

d = 1.5;   % larger d generates greater turbidity
simulated = Turbidity(color,underwater,d);

figure,imshow([input,color,simulated])
