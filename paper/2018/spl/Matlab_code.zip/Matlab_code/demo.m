clc
clear

X = imread('1.jpg');

pyramid_layers = 4; % the total number of laplacian pyramid levels

if size(X,3) > 1 % for RGB images, process the V channel in HSV color space
    
    HSV = rgb2hsv(X);
    V = HSV(:,:,3);
    V = uint8(255 * V);
    
    tic
    [ tmp_global, tmp_final ] = processing(V, pyramid_layers); 
    toc
    
    HSV(:,:,3) = im2double(tmp_global);
    Y_global = hsv2rgb(HSV);
 
    HSV(:,:,3) = im2double(tmp_final);
    Y_final = hsv2rgb(HSV);
    
else
    
    V = X;
    
    tic
    [ tmp_global, tmp_final ]= processing(V, pyramid_layers); 
    toc
    
    Y_global = im2double(tmp_global);
    Y_final = im2double(tmp_final);
    
end

%%% display histogram
hist_input = data2imhist(V);
hist_global = data2imhist(tmp_global);
hist_final = data2imhist(tmp_final);

if size(X,3) > 1
    hist_input = cat(3,hist_input,hist_input,hist_input);
    hist_global = cat(3,hist_global,hist_global,hist_global);
    hist_final = cat(3,hist_final,hist_final,hist_final);
end


figure,imshow([  im2double(X), Y_global, Y_final;   hist_input, hist_global, hist_final  ]);
title('From left to right:         input,      global enhancement,      final result');
