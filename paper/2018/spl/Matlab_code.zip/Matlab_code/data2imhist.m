function [out] = data2imhist(data)

g = 0:255;
h = hist(double(data(:)),g);
h = h / sum(h);
[H,W] = size(data);

w = ceil(W/length(g));
h = h / sum(h);
out = ones(H,length(h)*w);
h = h / max(h);
h = round(h*H);

for i = 1:length(h)
    out(1:h(i),w*(i-1)+1:w*i) = 0;
end

out = flipud(out);
a = 0.5;
out = [a*ones(w,size(out,2)); out; a*ones(w,size(out,2))];
out = [a*ones(size(out,1),w) out a*ones(size(out,1),w)];
out = imresize(out,[round(H * 0.25),W]);
end