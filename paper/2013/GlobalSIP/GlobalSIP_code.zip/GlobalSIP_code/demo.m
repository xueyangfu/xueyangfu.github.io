clc;
clear all;


input = imread('1.jpg'); 


output = processing(input);


figure,imshow([input,output])




