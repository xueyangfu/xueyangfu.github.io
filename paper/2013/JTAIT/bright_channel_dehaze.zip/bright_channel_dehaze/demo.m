clc;
clear all;

input = imread('1.jpg');
input = im2double(input);

output = dehaze(input);

figure;
imshow([input,output]);