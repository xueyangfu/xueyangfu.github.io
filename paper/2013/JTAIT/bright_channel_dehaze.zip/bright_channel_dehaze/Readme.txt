run 'demo' and see the result

Demo code for "Single image de-haze under non-uniform illumination using bright channel prior"

