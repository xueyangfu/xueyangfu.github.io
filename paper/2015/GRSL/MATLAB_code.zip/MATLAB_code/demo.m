clc;
clear all;



filename = strcat('.\images\1.png');
% filename = strcat('.\images\7.1.01.tiff');
% filename = strcat('.\images\5.tif');   % 5.tif is a 16-bit gray image and can be also directly enhanced by our method
% filename = strcat('.\images\house.jpg');   % the contrast enhancement to color images is to apply the algorithm to the V layer of the HSV space


[input, output] = processing( filename );

figure, imshow(input),  title('input');
figure, imshow(output), title('output');