#!/usr/bin/env python2
# -*- coding: utf-8 -*-


# This is a re-implementation of training code of our paper:
# X. Fu, J. Huang, D. Zeng, Y. Huang, X. Ding and J. Paisley. “Removing Rain from Single Images via a Deep Detail Network”, CVPR, 2017.
# author: Xueyang Fu (fxy@stu.xmu.edu.cn)

import os
import re
import random
import numpy as np
import tensorflow as tf
import matplotlib.image as img
import matplotlib.pyplot as plt
from GuidedFilter import guided_filter
from tensorflow.python.ops import control_flow_ops
from tensorflow.python.training import moving_averages


################ Batch Normalization setting ################
MOVING_AVERAGE_DECAY = 0.9997
BN_EPSILON = 0.001
BN_DECAY = MOVING_AVERAGE_DECAY
UPDATE_OPS_COLLECTION = 'Derain_update_ops'  
DERAIN_VARIABLES = 'Derain_variables'
#############################################################


##################### Select GPU device ####################################
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
############################################################################

tf.reset_default_graph()

##################### Network parameters ###################################
num_feature = 16             # number of feature maps
num_channels = 3             # number of input's channels 
patch_size = 64              # patch size 
learning_rate = 0.1          # learning rate
iterations = int(8e4)        # iterations
batch_size = 20              # batch size
save_model_path = "./model/" # saved model's path
model_name = 'model-epoch'   # saved model's name
############################################################################


input_path = "./TrainData/input/"    # the path of rainy images
gt_path = "./TrainData/label/"       # the path of ground truth



# randomly select image patches
def read_data(input_path, gt_path, size_input, num_channel, batch_size):
    input_files= os.listdir(input_path)
    gt_files= os.listdir(gt_path)  
    
    Data  = np.zeros((batch_size, size_input, size_input, num_channel)) 
    Label = np.zeros((batch_size, size_input, size_input, num_channel)) 
  
    for i in range(batch_size):
  
        r_idx = random.randint(0,len(input_files)-1)
    
        rainy = img.imread(input_path + input_files[r_idx])
        if np.max(rainy) > 1:
           rainy = rainy/255.0

        label = img.imread(gt_path + gt_files[r_idx])
        if np.max(label) > 1:
           label = label/255.0

        x = random.randint(0,rainy.shape[0] - size_input)
        y = random.randint(0,rainy.shape[1] - size_input)

        subim_input = rainy[x : x+size_input, y : y+size_input, :]
        subim_label = label[x : x+size_input, y : y+size_input, :]

        Data[i,:,:,:] = subim_input
        Label[i,:,:,:] = subim_label
		
    return Data, Label


# get variables for batch normalization
def _get_variable(name,
                  shape,
                  initializer,
                  weight_decay=0.0,
                  dtype='float',
                  trainable=True):

    if weight_decay > 0:
        regularizer = tf.contrib.layers.l2_regularizer(weight_decay)
    else:
        regularizer = None
    collections = [tf.GraphKeys.GLOBAL_VARIABLES, DERAIN_VARIABLES]
    return tf.get_variable(name,
                           shape=shape,
                           initializer=initializer,
                           dtype=dtype,
                           regularizer=regularizer,
                           collections=collections,
                           trainable=trainable)
    
# batch normalization
def bn(x, c):
    x_shape = x.get_shape()
    params_shape = x_shape[-1:]


    axis = list(range(len(x_shape) - 1))

    beta = _get_variable('beta',
                         params_shape,
                         initializer=tf.zeros_initializer)
    gamma = _get_variable('gamma',
                          params_shape,
                          initializer=tf.ones_initializer)

    moving_mean = _get_variable('moving_mean',
                                params_shape,
                                initializer=tf.zeros_initializer,
                                trainable=False)
    moving_variance = _get_variable('moving_variance',
                                    params_shape,
                                    initializer=tf.ones_initializer,
                                    trainable=False)

    # These ops will only be preformed when training.
    mean, variance = tf.nn.moments(x, axis)
    update_moving_mean = moving_averages.assign_moving_average(moving_mean,
                                                               mean, BN_DECAY)
    update_moving_variance = moving_averages.assign_moving_average(
        moving_variance, variance, BN_DECAY)
    tf.add_to_collection(UPDATE_OPS_COLLECTION, update_moving_mean)
    tf.add_to_collection(UPDATE_OPS_COLLECTION, update_moving_variance)

    mean, variance = control_flow_ops.cond(
        c, lambda: (mean, variance),
        lambda: (moving_mean, moving_variance))

    x = tf.nn.batch_normalization(x, mean, variance, beta, gamma, BN_EPSILON)
    
    return x


# initialize weights
def create_kernel(name, shape):
    regularizer = tf.contrib.layers.l2_regularizer(scale = 1e-10)
    initializer=tf.contrib.layers.xavier_initializer()
    
    new_variables = tf.get_variable(name=name, shape=shape, initializer=initializer,
                                    regularizer=regularizer, trainable=True)
    return new_variables



# network structure
def inference(images, is_training):
    base = guided_filter(images, images, 15, 1, nhwc=True) # using guided filter for obtaining base layer
    detail = images - base   # detail layer
	
    c = tf.convert_to_tensor(is_training, dtype='bool', name='is_training')

   #  layer 1
    with tf.variable_scope('conv_1'):
         kernel = create_kernel(name='weights_1', shape=[3, 3, num_channels, num_feature])
         biases = tf.Variable(tf.constant(0.0, shape=[num_feature], dtype=tf.float32), trainable=True, name='biases_1')      

         conv1 = tf.nn.conv2d(detail, kernel, [1, 1, 1, 1], padding='SAME')
         bias1 = tf.nn.bias_add(conv1, biases)
      
         bias1 = bn(bias1,c)

         conv_shortcut = tf.nn.relu(bias1)
  
   #  layers 2 to 25
    for i in range(12):
        with tf.variable_scope('conv_%s'%(i*2+2)):
             kernel = create_kernel(name=('weights_%s'%(i*2+2)), shape=[3, 3, num_feature, num_feature])
             biases = tf.Variable(tf.constant(0.0, shape=[num_feature], dtype=tf.float32), trainable=True, name=('biases_%s'%(i*2+2)))

             conv_tmp1 = tf.nn.conv2d(conv_shortcut, kernel, [1, 1, 1, 1], padding='SAME')     
             bias_tmp1 = tf.nn.bias_add(conv_tmp1, biases)
       
             bias_tmp1 = bn(bias_tmp1,c)

             out_tmp1 = tf.nn.relu(bias_tmp1)

  
        with tf.variable_scope('conv_%s'%(i*2+3)): 
             kernel = create_kernel(name=('weights_%s'%(i*2+3)), shape=[3, 3, num_feature, num_feature])
             biases = tf.Variable(tf.constant(0.0, shape=[num_feature], dtype=tf.float32), trainable=True, name=('biases_%s'%(i*2+3)))
 
             conv_tmp2 = tf.nn.conv2d(out_tmp1, kernel, [1, 1, 1, 1], padding='SAME')     
             bias_tmp2 = tf.nn.bias_add(conv_tmp2, biases)
       
             bias_tmp2 = bn(bias_tmp2,c)

             bias_tmp2 = tf.nn.relu(bias_tmp2)  
			 
             conv_shortcut = tf.add(conv_shortcut, bias_tmp2)

  
   # layer 26
    with tf.variable_scope('conv_26'):
         kernel = create_kernel(name='weights_26', shape=[3, 3, num_feature, num_channels])   
         biases = tf.Variable(tf.constant(0.0, shape=[num_channels], dtype=tf.float32), trainable=True, name='biases_26')

         conv_final = tf.nn.conv2d(conv_shortcut, kernel, [1, 1, 1, 1], padding='SAME')
         bias_final = tf.nn.bias_add(conv_final, biases)

         neg_residual = bn(bias_final,c)

         final_out = tf.nn.relu(tf.add(images, neg_residual))

    return final_out

  


if __name__ == '__main__':
   images = tf.placeholder(tf.float32, shape=(None, patch_size, patch_size, num_channels))  # data
   labels = tf.placeholder(tf.float32, shape=(None, patch_size, patch_size, num_channels))  # label
  
   outputs = inference(images, is_training = True)
  
   loss = tf.reduce_mean(tf.square(labels - outputs))    # MSE loss
   
   lr_ = learning_rate
   lr = tf.placeholder(tf.float32 ,shape = [])  
   
   g_optim =  tf.train.MomentumOptimizer(lr, 0.9).minimize(loss) 
   
   batchnorm_updates = tf.get_collection(UPDATE_OPS_COLLECTION)
   batchnorm_updates_op = tf.group(*batchnorm_updates)

   train_op = tf.group(g_optim, batchnorm_updates_op)
  
   saver = tf.train.Saver(max_to_keep = 5) 
   config = tf.ConfigProto()
   config.gpu_options.per_process_gpu_memory_fraction = 0.8 # GPU setting
   config.gpu_options.allow_growth = True
  
   validation_data, validation_label =  read_data(input_path, gt_path, patch_size, num_channels, batch_size) #  data for validation
   print("Check patch pair:")  
   plt.subplot(1,2,1)     
   plt.imshow(validation_data[0,:,:,:])
   plt.title('input')         
   plt.subplot(1,2,2)    
   plt.imshow(validation_label[0,:,:,:])
   plt.title('ground truth')        
   plt.show()   
   
   
   
   with tf.Session(config=config) as sess:
        sess.run(tf.global_variables_initializer())
		
        if tf.train.get_checkpoint_state('./model/'):   # load previous trained models
           ckpt = tf.train.latest_checkpoint('./model/')
           saver.restore(sess, ckpt)
           ckpt_num = re.findall(r'(\w*[0-9]+)\w*',ckpt)
           start_point = int(ckpt_num[0])    
           print("Successfully load previous model")
   
        else:   # re-training if no previous trained models
           start_point = 0    
           print("re-training")

        for j in range(start_point,iterations):   #  iterations
            if j+1 > int(3e4):
                lr_ = learning_rate*0.1
            if j+1 > int(6e4):
                lr_ = learning_rate*0.01             
                
            train_data, train_label = read_data(input_path, gt_path, patch_size, num_channels, batch_size) 
			
            _,Training_Loss = sess.run([train_op,loss], feed_dict={images: train_data, labels: train_label, lr: lr_}) # training
      
            if np.mod(j+1,100) == 0 and j != 0: # save the model every 100 iterations
               Validation_Loss = sess.run(loss,  feed_dict={images: validation_data, labels: validation_label})  # validation loss
               
               print ('%d / %d iteraions, learning rate = %.3f, Training Loss = %.4f,  Validation Loss = %.4f' 
                      % (j+1, iterations, lr_, Training_Loss, Validation_Loss))   
               
               save_path_full = os.path.join(save_model_path, model_name) # save model
               saver.save(sess, save_path_full, global_step = j+1)