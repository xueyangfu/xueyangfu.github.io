#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import os
import matplotlib.image as img
import numpy as np
import random
import h5py


clean_path = "./image/label/"
rainy_path = "./image/input/"

  
files= os.listdir(clean_path)

size_input = 64  # size of the training patch
num_channel = 3  # number of the input's channels.
num_files = 2001  # total ( num_files - 1 ) training h5 files, the last one is used for validation
num_patch = 500  # number of patches in each h5 file.



for j in range(num_files):

  Data = np.zeros((num_patch,size_input,size_input,num_channel)) 
  Label = np.zeros((num_patch,size_input,size_input,num_channel)) 
  
  for i in range(num_patch):
  
    r_idx = random.randint(0,len(files)-1)
    
    rainy = img.imread(rainy_path + files[r_idx])
    rainy = rainy/255.0

    label = img.imread(clean_path + files[r_idx])
    label = label/255.0

    x = random.randint(0,rainy.shape[0] - size_input)
    y = random.randint(0,rainy.shape[1] - size_input)

    subim_input = rainy[x : x+size_input, y : y+size_input, :]
    subim_label = label[x : x+size_input, y : y+size_input, :]

    Data[i,:,:,:] = subim_input
    Label[i,:,:,:] = subim_label
  
  if j+1 < num_files:
    f = h5py.File('./h5data/train' + str(j+1) + '.h5','w')   
    f['data'] = Data                 
    f['label'] = Label  
    f.close()  
    print(str(j+1)+ '/' + str(num_files-1) + ' training h5 files are generated')
    
  else:
    f = h5py.File('./h5data/validation.h5','w')   
    f['data'] = Data                 
    f['label'] = Label  
    f.close()  
    print('validation h5 file is generated')
  
print('all h5 files are generated')