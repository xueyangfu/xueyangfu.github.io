clc 
clear

input = imread('.\images\1.jpg');


alpha = 0.5;   % parameter alpha

output = undert_water(input,alpha);

figure,imshow([input,output])

