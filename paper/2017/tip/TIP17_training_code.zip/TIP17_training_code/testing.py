# -*- coding: utf-8 -*-
#!/usr/bin/env python2



# This is a re-implementation of testing code of this paper:
# X. Fu, J. Huang, X. Ding, Y. Liao and J. Paisley. “Clearing the Skies: A deep network architecture for single-image rain removal”, 
# IEEE Transactions on Image Processing, vol. 26, no. 6, pp. 2944-2956, 2017.
# author: Xueyang Fu (fxy@stu.xmu.edu.cn)

import os
import numpy as np
import tensorflow as tf
import training as DerainNet
import matplotlib.image as img
import matplotlib.pyplot as plt

##################### Select GPU device ####################################
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
############################################################################

tf.reset_default_graph()


file = "1.jpg"
ori = img.imread(file)
if np.max(ori) > 1:
   ori = ori/255.0

ori_expand = np.zeros([ori.shape[0] + 22, ori.shape[1] + 22, ori.shape[2]])
for j in range(3):
  ori_expand[:,:,j] = np.pad(ori[:,:,j], 11, 'symmetric')
ori_expand = np.expand_dims(ori_expand[:,:,:], axis = 0)

tensor_input = tf.placeholder(tf.float32, shape=(1, ori_expand.shape[1], ori_expand.shape[2], ori_expand.shape[3]))

detail_out, base_out = DerainNet.inference(tensor_input)

saver = tf.train.Saver()
config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.8 # GPU setting
config.gpu_options.allow_growth = True

with tf.Session(config=config) as sess:

     if tf.train.get_checkpoint_state('./model/'):  
        ckpt = tf.train.latest_checkpoint('./model/')
        saver.restore(sess, ckpt)
        print ("load new model")

     else:
        saver.restore(sess, "./model/test-model/model")                                                              
        print ("load pre-trained model")                            
        
              
     detail, base  = sess.run([detail_out, base_out], feed_dict={tensor_input:ori_expand})

     detail = detail[0,:,:,:] 
     detail = detail[7:detail.shape[0]-7, 7:detail.shape[1]-7, :]
    
     base = base[0,:,:,:] 
     base = base[11:base.shape[0]-11, 11:base.shape[1]-11, :]    
    
     derained = detail + base
     
     derained[np.where(derained < 0. )] = 0.
     derained[np.where(derained > 1. )] = 1.

     plt.subplot(1,2,1)     
     plt.imshow(ori)      
     plt.title('input')   

     plt.subplot(1,2,2)    
     plt.imshow(derained)
     plt.title('output')   

     plt.show()
     