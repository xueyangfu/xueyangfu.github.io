# -*- coding: utf-8 -*-
#!/usr/bin/env python2



# This is a re-implementation of testing code of this paper:
# X. Fu, J. Huang, X. Ding, Y. Liao and J. Paisley. “Clearing the Skies: A deep network architecture for single-image rain removal”, 
# IEEE Transactions on Image Processing, vol. 26, no. 6, pp. 2944-2956, 2017.
# author: Xueyang Fu (fxy@stu.xmu.edu.cn)

import os
import training as DerainNet
import tensorflow as tf
import matplotlib.pyplot as plt
import matplotlib.image as img
import numpy as np
import cv2

##################### Select GPU device ####################################
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
############################################################################
#os.environ['CUDA_VISIBLE_DEVICES'] = str(monitoring_gpu.GPU_INDEX)
############################################################################


        
def guided_filter1(data, height, width):
    r = 15
    eps = 1.0
    channel = 3
    batch_q = np.zeros((height, width, channel))
    for j in range(channel):
            I = data[:, :,j] 
            p = data[:, :,j] 
            ones_array = np.ones([height, width])
            N = cv2.boxFilter(ones_array, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0)
            mean_I = cv2.boxFilter(I, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            mean_p = cv2.boxFilter(p, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            mean_Ip = cv2.boxFilter(I * p, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            cov_Ip = mean_Ip - mean_I * mean_p
            mean_II = cv2.boxFilter(I * I, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            var_I = mean_II - mean_I * mean_I
            a = cov_Ip / (var_I + eps) 
            b = mean_p - a * mean_I
            mean_a = cv2.boxFilter(a , -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            mean_b = cv2.boxFilter(b , -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            q = mean_a * I + mean_b 
            batch_q[:, :,j] = q 
    return batch_q


file = "1.jpg"
ori = img.imread(file)
ori = ori/255.0

base = guided_filter1(ori, ori.shape[0], ori.shape[1])
detail = ori - base

details = np.zeros([ori.shape[0]+22, ori.shape[1]+22, ori.shape[2]])
for j in range(3):
  tmp = detail[:,:,j]
  details[:,:,j] = np.pad(tmp, 11, 'symmetric')
details = np.expand_dims(details[:,:,:], axis = 0)


image = tf.placeholder(tf.float32, shape=(1, details.shape[1], details.shape[2], details.shape[3]))

out = DerainNet.inference(image)

saver = tf.train.Saver()
config = tf.ConfigProto()
config.gpu_options.per_process_gpu_memory_fraction = 0.5
config.gpu_options.allow_growth = True

with tf.Session(config=config) as sess:
    
    if tf.train.get_checkpoint_state('./model/'):  
        ckpt = tf.train.latest_checkpoint('./model/')
        saver.restore(sess, ckpt)
        print ("load new model")

    else:
        saver.restore(sess, "./model/test-model/model") # this model uses 128 feature maps and for debug only                                                                   
        print ("load pre-trained model")                            
        
        
        
    detail_out  = sess.run(out, feed_dict={image:details})

    detail_out = detail_out[0,:,:,:] 
    derained = detail_out[7:detail_out.shape[0]-7, 7:detail_out.shape[1]-7, :] + base
    derained[np.where(derained < 0. )] = 0.
    derained[np.where(derained > 1. )] = 1.


    plt.subplot(1,2,1)     
    plt.imshow(ori)      
    plt.title('input')   

    plt.subplot(1,2,2)    
    plt.imshow(derained)
    plt.title('output')   

    plt.show()
