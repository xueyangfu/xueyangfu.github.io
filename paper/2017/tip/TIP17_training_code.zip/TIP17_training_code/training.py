# -*- coding: utf-8 -*-
#!/usr/bin/env python2



# This is a re-implementation of training code of this paper:
# X. Fu, J. Huang, X. Ding, Y. Liao and J. Paisley. “Clearing the Skies: A deep network architecture for single-image rain removal”, 
# IEEE Transactions on Image Processing, vol. 26, no. 6, pp. 2944-2956, 2017.
# author: Xueyang Fu (fxy@stu.xmu.edu.cn)

import os
import tensorflow as tf
import h5py
import numpy as np
import cv2
import re
import matplotlib.pyplot as plt

##################### Select GPU device ####################################
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
############################################################################
#os.environ['CUDA_VISIBLE_DEVICES'] = str(monitoring_gpu.GPU_INDEX)
############################################################################

FLAGS = tf.app.flags.FLAGS
tf.app.flags.DEFINE_integer('num_h5_file', 2000,
                            """number of training h5 files.""")
tf.app.flags.DEFINE_integer('num_patches', 500,
                            """number of patches in each h5 file.""")
tf.app.flags.DEFINE_integer('learning_rate', 1e-3,
                            """learning rate.""")
tf.app.flags.DEFINE_integer('epoch', 150,
                            """epoch.""")
tf.app.flags.DEFINE_integer('num_feature', 128,    # 512 used in the paper
                            """number of feature maps.""")
tf.app.flags.DEFINE_integer('batch_size', 10,
                            """batch size.""")
tf.app.flags.DEFINE_integer('num_channels', 3,
                            """number of input channels.""")
tf.app.flags.DEFINE_integer('image_size', 64,
                            """size of the input.""")
tf.app.flags.DEFINE_integer('label_size', 56,
                            """size of the output.""")

tf.app.flags.DEFINE_string("data_path", "./data_generation/h5data/", "The path of h5 files")

tf.app.flags.DEFINE_string("save_model_path", "./model/", "The path of trained model")

# read h5 file
def read_data(file):
  with h5py.File(file, 'r') as hf:
    data = hf.get('data')
    label = hf.get('label')
    return np.array(data), np.array(label)


# DerainNet network structure
def inference(images):

  # conv1
  with tf.variable_scope('conv_1'):
    kernel = tf.Variable(tf.random_normal([16, 16, FLAGS.num_channels, FLAGS.num_feature], dtype=tf.float32, stddev=1e-3), trainable=True, name='weights1')
    biases = tf.Variable(tf.constant(0.0, shape=[FLAGS.num_feature], dtype=tf.float32), trainable=True, name='biases1')

    conv = tf.nn.conv2d(images, kernel, [1, 1, 1, 1], padding='VALID')
    bias = tf.nn.bias_add(conv, biases)

    conv1 = tf.nn.tanh(bias)


   # conv2
  with tf.variable_scope('conv_2'):
    kernel = tf.Variable(tf.random_normal([1, 1, FLAGS.num_feature, FLAGS.num_feature], dtype=tf.float32, stddev=1e-3), trainable=True, name='weights2')   
    biases = tf.Variable(tf.constant(0.0, shape=[FLAGS.num_feature], dtype=tf.float32), trainable=True, name='biases2')

    conv = tf.nn.conv2d(conv1, kernel, [1, 1, 1, 1], padding='VALID')
    bias = tf.nn.bias_add(conv, biases)

    conv2 = tf.nn.tanh(bias)


  # conv3
  with tf.variable_scope('conv_3'):
    kernel = tf.Variable(tf.random_normal([8, 8, FLAGS.num_channels,FLAGS.num_feature], dtype=tf.float32, stddev=1e-3), trainable=True, name='weights3')
    biases = tf.Variable(tf.constant(0.0, shape=[FLAGS.num_channels], dtype=tf.float32), trainable=True, name='biases3')

    conv = tf.nn.conv2d_transpose(conv2,kernel,[tf.shape(images)[0], tf.shape(images)[1]-8, tf.shape(images)[2]-8, FLAGS.num_channels],[1, 1, 1, 1],padding='VALID')   
    out = tf.nn.bias_add(conv, biases)


  return out
  

# guided filter
def guided_filter(data):
    r = 15 
    eps = 1.0
    batch_q = np.zeros((FLAGS.num_patches, FLAGS.image_size, FLAGS.image_size, FLAGS.num_channels))
    for i in range(FLAGS.num_patches):
        for j in range(FLAGS.num_channels):
            I = data[i, :, :, j]
            p = data[i, :, :, j]
            ones_array = np.ones([FLAGS.image_size, FLAGS.image_size])
            N = cv2.boxFilter(ones_array, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0)
            mean_I = cv2.boxFilter(I, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            mean_p = cv2.boxFilter(p, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            mean_Ip = cv2.boxFilter(I * p, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            cov_Ip = mean_Ip - mean_I * mean_p
            mean_II = cv2.boxFilter(I * I, -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            var_I = mean_II - mean_I * mean_I
            a = cov_Ip / (var_I + eps) 
            b = mean_p - a * mean_I
            mean_a = cv2.boxFilter(a , -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            mean_b = cv2.boxFilter(b , -1, (2 * r + 1, 2 * r + 1), normalize = False, borderType = 0) / N
            q = mean_a * I + mean_b 
            batch_q[i, :, :,j] = q 
    return batch_q



if __name__ == '__main__':

  images = tf.placeholder(tf.float32, shape=(None, FLAGS.image_size, FLAGS.image_size, FLAGS.num_channels))
  labels = tf.placeholder(tf.float32, shape=(None, FLAGS.label_size, FLAGS.label_size, FLAGS.num_channels))
  
  outputs = inference(images)
  
  loss = tf.reduce_mean(tf.square(labels - outputs))  # MSE loss
  
  lr_ = FLAGS.learning_rate 
  lr  = tf.placeholder(tf.float32 ,shape = []) 
  
  g_optim =  tf.train.AdamOptimizer(lr).minimize(loss) # Optimization method: Adam

  saver = tf.train.Saver(max_to_keep = 5)
  config = tf.ConfigProto()
  config.gpu_options.per_process_gpu_memory_fraction = 0.5 # GPU setting
  config.gpu_options.allow_growth = True
  
  
  data_path = FLAGS.data_path
  save_path = FLAGS.save_model_path 
  epoch = int(FLAGS.epoch) 

  with tf.Session(config=config) as sess:

    sess.run(tf.global_variables_initializer())
    

    validation_data_name = "validation.h5"
    validation_data, validation_label = read_data(data_path + validation_data_name)

    validation_data = np.transpose(validation_data, (0,2,3,1))
    validation_detail_data = validation_data - guided_filter(validation_data)  # validation input detail layer

    validation_label = np.transpose(validation_label, (0,2,3,1))
    validation_detail_label = validation_label - guided_filter(validation_label) # validation label detail layer
    validation_detail_label = validation_detail_label[:,4:4+FLAGS.label_size,4:4+FLAGS.label_size,:]   # output size 56


   
    if tf.train.get_checkpoint_state('./model/'):   # load previous trained model 
      ckpt = tf.train.latest_checkpoint('./model/')
      saver.restore(sess, ckpt)
      ckpt_num = re.findall(r"\d",ckpt)
      if len(ckpt_num) == 3:
        start_point = 100*int(ckpt_num[0])+10*int(ckpt_num[1])+int(ckpt_num[2])
      elif len(ckpt_num) == 2:
        start_point = 10*int(ckpt_num[0])+int(ckpt_num[1])
      else:
        start_point = int(ckpt_num[0])      
      print("Load success")
   
    else:  # re-training when no model found
      print("re-training")
      start_point = 0   


    for j in range(start_point,epoch):   # epoch

      Training_Loss = 0.

      for num in range(FLAGS.num_h5_file):   # h5 files
        train_data_name = "train" + str(num+1) + ".h5"
        train_data, train_label = read_data(data_path + train_data_name)

        train_data = np.transpose(train_data, (0,2,3,1))
        train_detail_data = train_data - guided_filter(train_data)  # training input detail layer

        train_label = np.transpose(train_label, (0,2,3,1))
        train_detail_label = train_label - guided_filter(train_label)# training label detail layer
        train_detail_label = train_detail_label[:,4:4+FLAGS.label_size,4:4+FLAGS.label_size,:]  # output size 56


        data_size = int(train_data.shape[0] / FLAGS.batch_size)   # the number of batch
        for i in range(data_size):   
          rand_index = np.arange(int(i*FLAGS.batch_size),int((i+1)*FLAGS.batch_size))
          batch_data = train_detail_data[rand_index,:,:,:]    # batch data
          batch_label = train_detail_label[rand_index,:,:,:]  # batch label

          _,lossvalue = sess.run([g_optim,loss], feed_dict={images:batch_data, labels:batch_label, lr: lr_})
          Training_Loss += lossvalue     # trainging loss 
  

      Training_Loss /=  (data_size * FLAGS.num_h5_file)

      model_name = 'model-epoch'  # save model
      save_path_full = os.path.join(save_path, model_name)
      saver.save(sess, save_path_full, global_step = j+1)

      Validation_Loss  = sess.run(loss,  feed_dict={images: validation_detail_data, labels:validation_detail_label}) # validation loss 

      print ('%d epoch is finished, Training_Loss = %.4f, Validation_Loss = %.4f' %
               (j+1, Training_Loss, Validation_Loss))
