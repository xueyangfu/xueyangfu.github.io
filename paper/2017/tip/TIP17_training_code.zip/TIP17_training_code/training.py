# -*- coding: utf-8 -*-
#!/usr/bin/env python2



# This is a re-implementation of training code of this paper:
# X. Fu, J. Huang, X. Ding, Y. Liao and J. Paisley. “Clearing the Skies: A deep network architecture for single-image rain removal”, 
# IEEE Transactions on Image Processing, vol. 26, no. 6, pp. 2944-2956, 2017.
# author: Xueyang Fu (fxy@stu.xmu.edu.cn)

import os
import re
import random
import numpy as np
import tensorflow as tf
import matplotlib.image as img
import matplotlib.pyplot as plt
from GuidedFilter import guided_filter


##################### Select GPU device ####################################
os.environ['CUDA_VISIBLE_DEVICES'] = "0"
############################################################################

tf.reset_default_graph()

##################### Network parameters ###################################
num_feature = 512            # number of feature maps
num_channels = 3             # number of input's channels 
patch_size = 64              # patch size 
learning_rate = 0.001        # learning rate
iterations = int(1e5)        # iterations
batch_size = 10              # batch size
save_model_path = "./model/" # saved model's path
model_name = 'model-epoch'   # saved model's name
############################################################################

input_path = "./TrainData/input/" # the path of training data
gt_path = "./TrainData/label/"       # the path of training label


# randomly select image patches
def read_data(input_path, gt_path, size_input, num_channel, batch_size):
    input_files= os.listdir(input_path)
    gt_files= os.listdir(gt_path)  
    
    Data  = np.zeros((batch_size, size_input, size_input, num_channel)) 
    Label = np.zeros((batch_size, size_input, size_input, num_channel)) 
  
    for i in range(batch_size):
  
        r_idx = random.randint(0,len(input_files)-1)
    
        rainy = img.imread(input_path + input_files[r_idx])
        if np.max(rainy) > 1:
           rainy = rainy/255.0

        label = img.imread(gt_path + gt_files[r_idx])
        if np.max(label) > 1:
           label = label/255.0

        x = random.randint(0,rainy.shape[0] - size_input)
        y = random.randint(0,rainy.shape[1] - size_input)

        subim_input = rainy[x : x+size_input, y : y+size_input, :]
        subim_label = label[x : x+size_input, y : y+size_input, :]

        Data[i,:,:,:] = subim_input
        Label[i,:,:,:] = subim_label
		
    return Data, Label


# DerainNet network structure
def inference(images):
    base = guided_filter(images,images, 15, 1, nhwc=True) # using guided filter for obtaining base layer
    detail = images - base   # detail layer
	
  # conv1
    with tf.variable_scope('conv_1'):
         kernel = tf.Variable(tf.random_normal([16, 16, num_channels, num_feature], dtype=tf.float32, stddev=1e-3), trainable=True, name='weights1')
         biases = tf.Variable(tf.constant(0.0, shape=[num_feature], dtype=tf.float32), trainable=True, name='biases1')

         conv = tf.nn.conv2d(detail, kernel, [1, 1, 1, 1], padding='VALID')
         bias = tf.nn.bias_add(conv, biases)

         conv1 = tf.nn.relu(bias) # ReLU makes training fast and stable


   # conv2
    with tf.variable_scope('conv_2'):
         kernel = tf.Variable(tf.random_normal([1, 1, num_feature, num_feature], dtype=tf.float32, stddev=1e-3), trainable=True, name='weights2')   
         biases = tf.Variable(tf.constant(0.0, shape=[num_feature], dtype=tf.float32), trainable=True, name='biases2')

         conv = tf.nn.conv2d(conv1, kernel, [1, 1, 1, 1], padding='VALID')
         bias = tf.nn.bias_add(conv, biases)

         conv2 = tf.nn.relu(bias)


  # conv3
    with tf.variable_scope('conv_3'):
         kernel = tf.Variable(tf.random_normal([8, 8, num_channels,num_feature], dtype=tf.float32, stddev=1e-3), trainable=True, name='weights3')
         biases = tf.Variable(tf.constant(0.0, shape=[num_channels], dtype=tf.float32), trainable=True, name='biases3')

         conv = tf.nn.conv2d_transpose(conv2,kernel,[tf.shape(images)[0], tf.shape(images)[1]-8, tf.shape(images)[2]-8, num_channels],[1, 1, 1, 1],padding='VALID')   
         out = tf.nn.bias_add(conv, biases)


    return out, base
  


if __name__ == '__main__':

   images = tf.placeholder(tf.float32, shape=(None, patch_size, patch_size, num_channels))
   labels = tf.placeholder(tf.float32, shape=(None, patch_size, patch_size, num_channels))
  
   details_label = labels - guided_filter(labels, labels, 15, 1, nhwc=True)
   details_label = details_label[:, 4:patch_size-4, 4:patch_size-4, :] # output size 56
  
   details_output, _ = inference(images)
  
   loss = tf.reduce_mean(tf.square( details_label - details_output ))  # MSE loss
  
   lr  = tf.placeholder(tf.float32 ,shape = [])  
   g_optim =  tf.train.AdamOptimizer(lr).minimize(loss) 

   saver = tf.train.Saver(max_to_keep = 5)
   config = tf.ConfigProto()
   config.gpu_options.per_process_gpu_memory_fraction = 0.8 # GPU setting
   config.gpu_options.allow_growth = True
  
   validation_data, validation_label = read_data(input_path, gt_path, patch_size, num_channels, batch_size)
   print("Check patch pair:")  
   plt.subplot(1,2,1)     
   plt.imshow(validation_data[0,:,:,:])
   plt.title('input')         
   plt.subplot(1,2,2)    
   plt.imshow(validation_label[0,:,:,:])
   plt.title('ground truth')        
   plt.show()

   with tf.Session(config=config) as sess:
        sess.run(tf.global_variables_initializer())
    
        if tf.train.get_checkpoint_state('./model/'):   # load previous trained model 
           ckpt = tf.train.latest_checkpoint('./model/')
           saver.restore(sess, ckpt)
           ckpt_num = re.findall(r'(\w*[0-9]+)\w*',ckpt)
           start_point = int(ckpt_num[0])      
           print("Load success")
   
        else:  # re-training when no models found
           start_point = 0   
           print("re-training")

        for j in range(start_point, iterations):   # iterations
            train_data, train_label = read_data(input_path, gt_path, patch_size, num_channels, batch_size) 
            _,Training_Loss = sess.run([g_optim,loss], feed_dict={images: train_data, labels: train_label, lr: learning_rate}) # training
      
            if np.mod(j+1,100) == 0 and j != 0: # save the model every 100 iterations
               Validation_Loss = sess.run(loss,  feed_dict={images: validation_data, labels: validation_label})  # validation loss
               
               print ('%d / %d iteraions, Training Loss  = %.4f,   Validation Loss  = %.4f' % (j+1, iterations, Training_Loss, Validation_Loss))         
               save_path_full = os.path.join(save_model_path, model_name)
               saver.save(sess, save_path_full, global_step = j+1)